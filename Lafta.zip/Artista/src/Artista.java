public class Artista extends Thread {
    @Override
    public void run() {
        System.out.println("L'artista è pronto.");

        while (true) {
            // L'artista continua a lavorare finché il programma non viene interrotto manualmente

            try {
                Thread.sleep(1000); // Tempo impiegato dall'artista per eseguire un ritratto (1 secondo)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
