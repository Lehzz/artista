import java.util.concurrent.Semaphore;

public class Cliente extends Thread {
    private int idCliente;
    private int tempoAttesa;

    public Cliente(int idCliente, int tempoAttesa) {
        this.idCliente = idCliente;
        this.tempoAttesa = tempoAttesa;
    }

    @Override
    public void run() {
        System.out.println("Cliente " + idCliente + " arriva.");

        if (SimulazioneStreetArtist.getSedieDisponibili().tryAcquire()) {
            // Cliente ha ottenuto una sedia
            System.out.println("Cliente " + idCliente + " si siede sulla sedia.");

            try {
                Thread.sleep(tempoAttesa); // Tempo di attesa del cliente
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("Cliente " + idCliente + " si alza dopo " + tempoAttesa + "ms e si sposta nella zona di lavoro.");

            SimulazioneStreetArtist.getSedieDisponibili().release(); // Rilascia la sedia
        } else {
            // Cliente rinuncia a farsi fare il ritratto
            System.out.println("Cliente " + idCliente + " rinuncia a farsi fare il ritratto dopo un'attesa troppo lunga.");
        }
    }
}
