//Lafta Omar Artista di strada
import java.util.Random;
import java.util.concurrent.Semaphore;

public class SimulazioneStreetArtist {
    private static final int NUMERO_SEDI = 4; // Numero di sedie disponibili
    private static final int TEMPO_ATTESA_MASSIMO = 5000; // Tempo massimo di attesa di un cliente in millisecondi

    private static Semaphore sedieDisponibili; // Semaforo per tenere traccia delle sedie disponibili

    public static void main(String[] args) {
        setSedieDisponibili(new Semaphore(NUMERO_SEDI));

        Artista artista = new Artista();
        artista.start();

        Random random = new Random();

        // Genera nuovi clienti ad intervalli casuali
        for (int i = 1; i <= 10; i++) {
            Cliente cliente = new Cliente(i, random.nextInt(TEMPO_ATTESA_MASSIMO));
            cliente.start();

            // Attende un po' di tempo prima di generare il cliente successivo
            try {
                Thread.sleep(random.nextInt(2000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

	public static Semaphore getSedieDisponibili() {
		return sedieDisponibili;
	}

	public static void setSedieDisponibili(Semaphore sedieDisponibili) {
		SimulazioneStreetArtist.sedieDisponibili = sedieDisponibili;
	}
}


